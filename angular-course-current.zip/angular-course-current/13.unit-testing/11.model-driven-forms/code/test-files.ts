// Import spec files individually
import "./app/login.component.spec.ts";