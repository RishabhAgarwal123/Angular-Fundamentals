// Import spec files individually
import "./app/search.service.spec.ts";