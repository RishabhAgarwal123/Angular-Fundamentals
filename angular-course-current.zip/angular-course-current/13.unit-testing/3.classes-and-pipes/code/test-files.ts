// Import spec files individually
import "./app/auth.service.spec.ts";
import "./app/default.pipe.spec.ts";