// Import spec (test) files individually
import "./app/test.ts";