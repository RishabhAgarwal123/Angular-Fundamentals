// Import spec files individually
import "./app/hoverfocus.directive.spec.ts";