// Import spec files individually
import "./app/router.spec.ts";