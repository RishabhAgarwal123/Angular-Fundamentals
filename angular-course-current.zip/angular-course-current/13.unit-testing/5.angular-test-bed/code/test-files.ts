// Import spec files individually
import "./app/auth.service.spec.ts";
import "./app/login.component.spec.ts";